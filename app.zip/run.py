from app import app

app.debug =True
app.run(host='127.0.0.1')
